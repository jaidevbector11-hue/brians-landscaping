﻿document.addEventListener("DOMContentLoaded", () => {
  const nav = document.querySelector(".nav");
  const toggle = document.querySelector(".menu-toggle");
  if (toggle) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
  }

  document.querySelectorAll("[data-filter]").forEach((button) => {
    button.addEventListener("click", () => {
      const filter = button.dataset.filter;
      document.querySelectorAll("[data-filter]").forEach((b) => b.classList.remove("active"));
      button.classList.add("active");
      document.querySelectorAll("[data-cat]").forEach((card) => {
        card.hidden = filter !== "all" && card.dataset.cat !== filter;
      });
    });
  });

  const lightbox = document.createElement("div");
  lightbox.className = "lightbox";
  lightbox.innerHTML = '<button class="btn secondary" type="button">Close</button><img alt="">';
  document.body.append(lightbox);
  const lbImg = lightbox.querySelector("img");
  lightbox.querySelector("button").addEventListener("click", () => lightbox.classList.remove("open"));
  lightbox.addEventListener("click", (event) => {
    if (event.target === lightbox) lightbox.classList.remove("open");
  });
  document.querySelectorAll("[data-lightbox]").forEach((button) => {
    button.addEventListener("click", () => {
      const img = button.querySelector("img");
      lbImg.src = img.src;
      lbImg.alt = img.alt;
      lightbox.classList.add("open");
    });
  });

  document.querySelectorAll("[data-multistep]").forEach((form) => {
    const panels = Array.from(form.querySelectorAll("fieldset"));
    const stepButtons = Array.from(document.querySelectorAll(`[data-step-for="${form.id}"]`));
    let index = 0;
    const show = (next) => {
      index = Math.max(0, Math.min(next, panels.length - 1));
      panels.forEach((panel, i) => panel.hidden = i !== index);
      stepButtons.forEach((btn, i) => btn.classList.toggle("active", i === index));
      form.querySelector("[data-prev]").disabled = index === 0;
      form.querySelector("[data-next]").hidden = index === panels.length - 1;
      form.querySelector("[data-submit]").hidden = index !== panels.length - 1;
    };
    form.querySelector("[data-prev]").addEventListener("click", () => show(index - 1));
    form.querySelector("[data-next]").addEventListener("click", () => show(index + 1));
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (form.querySelector(".honeypot input")?.value) return;
      form.querySelector("[data-result]").hidden = false;
      form.querySelector("[data-result]").scrollIntoView({ behavior: "smooth", block: "center" });
    });
    show(0);
  });

  document.querySelectorAll(".slot").forEach((slot) => {
    slot.addEventListener("click", () => {
      document.querySelectorAll(".slot").forEach((s) => s.classList.remove("selected"));
      slot.classList.add("selected");
      const target = document.querySelector("#preferred-slot");
      if (target) target.value = slot.textContent.trim();
    });
  });
});
